package ma.WhiteLab;

import ma.WhiteLab.entities.enums.*;
import ma.WhiteLab.entities.patient.*;
import ma.WhiteLab.entities.consultation.Consultation;
import ma.WhiteLab.entities.personnel.Medecin;
import ma.WhiteLab.entities.planning.RendezVous;
import ma.WhiteLab.repository.modules.patient.impl.mySQL.*;
import ma.WhiteLab.repository.modules.consultation.impl.mySQL.*;
import ma.WhiteLab.repository.modules.personnel.impl.mySQL.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class TestPatient {

    public static void main(String[] args) {
        // ----------------------------
        // Répositories
        // ----------------------------
        PatientRepositoryImpl patientRepository = new PatientRepositoryImpl();
        DossierMedicalRepositoryImpl dossierMedicalRepository = new DossierMedicalRepositoryImpl();
        AntecedentRepositoryImpl antecedentRepository = new AntecedentRepositoryImpl();
        MedecinRepositoryImpl medecinRepository = new MedecinRepositoryImpl();
        ConsultationRepositoryImpl consultationRepository = new ConsultationRepositoryImpl();

        // ----------------------------
        // 1. Création du patient
        // ----------------------------
        Patient patient = Patient.builder()
                .nom("Doe")
                .prenom("John")
                .sexe(Sexe.Homme)
                .email("john.doe@example.com")
                .dateNaissance(LocalDate.of(1990, 1, 1))
                .adresse("123 Rue Principale")
                .telephone("0600000000")
                .assurance(Assurance.CNSS)
                .build();
        patientRepository.create(patient);
        System.out.println("Patient créé avec ID : " + patient.getId());

        // ----------------------------
        // 2. Création du médecin
        // ----------------------------
        Medecin medecin = Medecin.builder()
                .nom("Smith")
                .prenom("Alice")
                .specialite("Cardiologie")
                .build();
        medecinRepository.create(medecin);
        System.out.println("Médecin créé avec ID : " + medecin.getId());

        // ----------------------------
        // 3. Création du dossier médical et liaison avec patient et médecin
        // ----------------------------
        DossierMedical dossier = DossierMedical.builder()
                .historique("Historique médical initial")
                .pat(patient)
                .medcine(medecin)
                .build();
        dossierMedicalRepository.create(dossier);
        patient.setDossierMed(dossier); // liaison mémoire
        medecin.setDossiersMed(List.of(dossier)); // liaison mémoire
        System.out.println("Dossier médical créé avec ID : " + dossier.getId());

        // ----------------------------
        // 4. Création des antécédents et liaison avec patient
        // ----------------------------
        Antecedent antecedent1 = Antecedent.builder()
                .nom("Asthme")
                .description("Asthme léger depuis l'enfance")
                .categorie(CategorieAntecedent.ALLERGIE)
                .niveauDeRisk(NiveauDeRisk.MOYEN)
                .build();
        Antecedent antecedent2 = Antecedent.builder()
                .nom("Allergie")
                .description("Allergie aux arachides")
                .categorie(CategorieAntecedent.HABITUDE_DE_VIE)
                .niveauDeRisk(NiveauDeRisk.ELEVE)
                .build();
        antecedentRepository.create(antecedent1);
        antecedentRepository.create(antecedent2);

        patient.setAntecedents(List.of(antecedent1, antecedent2));
        System.out.println("Antécédents associés au patient.");

        // ----------------------------
        // 5. Création d'une consultation et liaison avec le dossier
        // ----------------------------
        Consultation consultation = Consultation.builder()
                .dossierMedical(dossier)
                .date(LocalDateTime.now())
                .status(StatusConsultation.EN_COURS)
                .notes("Consultation initiale")
                .observationsMedecin("Observations du médecin")
                .build();
        consultationRepository.create(consultation);
        dossier.setConsultations(List.of(consultation));
        System.out.println("Consultation créée avec ID : " + consultation.getId());

        // ----------------------------
        // 6. Test final et affichage
        // ----------------------------
        System.out.println("Test patient terminé avec toutes les liaisons en base et en mémoire.");
        System.out.println("Patient ID : " + patient.getId() + ", Dossier ID : " + patient.getDossierMed().getId());
        System.out.println("Médecin ID : " + medecin.getId() + ", Dossier lié au médecin ID : " + medecin.getDossiersMed().get(0).getId());
        System.out.println("Consultation ID : " + consultation.getId());
        System.out.println("Antécédents : ");
        patient.getAntecedents().forEach(a -> System.out.println(" - " + a.getNom() + " (" + a.getCategorie() + ")"));
    }
}
