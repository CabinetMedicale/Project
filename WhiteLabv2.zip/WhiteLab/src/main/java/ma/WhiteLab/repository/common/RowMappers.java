package ma.WhiteLab.repository.common;

import ma.WhiteLab.entities.BaseEntity;
import ma.WhiteLab.entities.cabinet.CabinetMedicale;
import ma.WhiteLab.entities.cabinet.Statistiques;
import ma.WhiteLab.entities.consultation.ActeMedical;
import ma.WhiteLab.entities.consultation.Consultation;
import ma.WhiteLab.entities.consultation.InterventionMedecin;
import ma.WhiteLab.entities.finance.Charges;
import ma.WhiteLab.entities.finance.Facture;
import ma.WhiteLab.entities.finance.Revenus;
import ma.WhiteLab.entities.finance.SuiviFinancier;
import ma.WhiteLab.entities.patient.*;
import ma.WhiteLab.entities.enums.*;
import ma.WhiteLab.entities.personnel.Admin;
import ma.WhiteLab.entities.personnel.Medecin;
import ma.WhiteLab.entities.personnel.Secretaire;
import ma.WhiteLab.entities.personnel.Staff;
import ma.WhiteLab.entities.planning.AgendaMensuel;
import ma.WhiteLab.entities.planning.RendezVous;
import ma.WhiteLab.entities.prescription.Medicament;
import ma.WhiteLab.entities.prescription.Ordonnance;
import ma.WhiteLab.entities.prescription.Prescription;
import ma.WhiteLab.entities.user.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class RowMappers {

    private RowMappers(){}

    // ============================================================
    //  MÉTHODE GLOBALE POUR MAPPER BaseEntity
    // ============================================================
    private static <T extends BaseEntity> T mapBaseEntity(ResultSet rs, T entity) throws SQLException {

        entity.setId(rs.getLong("id"));

        Timestamp dc = rs.getTimestamp("dateCreation");
        if (dc != null) entity.setDateCreation(dc.toLocalDateTime());

        Timestamp dm = rs.getTimestamp("dateMiseAJour");
        if (dm != null) entity.setDateMiseAJour(dm.toLocalDateTime());

        entity.setCreePar(rs.getString("creePar"));
        entity.setModifierPar(rs.getString("modifierPar"));

        return entity;
    }


    // ============================================================
    //  PATIENT
    // ============================================================
    public static Patient mapPatient(ResultSet rs) throws SQLException {

        Patient patientRow = mapBaseEntity(rs, new Patient());

        patientRow.setNom(rs.getString("nom"));
        patientRow.setPrenom(rs.getString("prenom"));
        patientRow.setAdresse(rs.getString("adresse"));
        patientRow.setTelephone(rs.getString("telephone"));
        patientRow.setEmail(rs.getString("email"));

        var dn = rs.getDate("dateNaissance");
        if (dn != null) patientRow.setDateNaissance(dn.toLocalDate());

        patientRow.setSexe(Sexe.valueOf(rs.getString("sexe")));
        patientRow.setAssurance(Assurance.valueOf(rs.getString("assurance")));

        // list vide : chargée dans le service
        patientRow.setAntecedents(new ArrayList<>());

        return patientRow;
    }


    // ============================================================
    //  ANTECEDENT
    // ============================================================
    public static Antecedent mapAntecedent(ResultSet rs) throws SQLException {

        Antecedent a = mapBaseEntity(rs, new Antecedent());

        a.setNom(rs.getString("nom"));
        a.setDescription(rs.getString("description"));

        String cat = rs.getString("categorie");
        if (cat != null) a.setCategorie(CategorieAntecedent.valueOf(cat));

        String niv = rs.getString("niveauRisque");
        if (niv != null) a.setNiveauDeRisk(NiveauDeRisk.valueOf(niv));

        return a;
    }


    // ============================================================
    //  CERTIFICAT
    // ============================================================
    public static Certificat mapCertificat(ResultSet rs) throws SQLException {

        Certificat c = mapBaseEntity(rs, new Certificat());

        Date dDebut = rs.getDate("dateDebut");
        if (dDebut != null) c.setDateDebut(dDebut.toLocalDate());

        Date dFin = rs.getDate("dateFin");
        if (dFin != null) c.setDateFin(dFin.toLocalDate());

        c.setDureeRepos(rs.getInt("dureeRepos"));
        c.setContenu(rs.getString("contenu"));

        return c;
    }


    // ============================================================
    //  DOSSIER MEDICAL
    // ============================================================
    public static DossierMedical mapDossierMedical(ResultSet rs) throws SQLException {

        DossierMedical d = mapBaseEntity(rs, new DossierMedical());

        d.setHistorique(rs.getString("historique"));

        return d;
    }


    // ============================================================
    //  NOTIFICATION
    // ============================================================
    public static Notification mapNotification(ResultSet rs) throws SQLException {

        Notification n = mapBaseEntity(rs, new Notification());

        String titre = rs.getString("titre");
        if (titre != null) n.setTitre(TitreNotification.valueOf(titre));

        n.setMessage(rs.getString("message"));

        Date d = rs.getDate("date");
        if (d != null) n.setDate(d.toLocalDate());

        Time t = rs.getTime("time");
        if (t != null) n.setTime(t.toLocalTime());

        String type = rs.getString("type");
        if (type != null) n.setType(TypeNotification.valueOf(type));

        String priorite = rs.getString("priorite");
        if (priorite != null) n.setPriorite(PrioriteNotification.valueOf(priorite));

        return n;
    }


    // ============================================================
    //  ROLE
    // ============================================================
    public static Role mapRole(ResultSet rs) throws SQLException {

        Role role = mapBaseEntity(rs, new Role());

        String libelle = rs.getString("libelle");
        if (libelle != null) role.setLibelle(RoleR.valueOf(libelle));

        String privs = rs.getString("privileges");
        if (privs != null && !privs.isBlank()) {
            role.setPrivileges(List.of(privs.split(",")));
        }

        return role;
    }


    // ============================================================
    //  UTILISATEUR (générique)
    // ============================================================
    public static <T extends Utilisateur> T mapUtilisateur(ResultSet rs, T utilisateur) throws SQLException {

        utilisateur = mapBaseEntity(rs, utilisateur);

        utilisateur.setNom(rs.getString("nom"));
        utilisateur.setPrenom(rs.getString("prenom"));
        utilisateur.setEmail(rs.getString("email"));
        utilisateur.setAdresse(rs.getString("adresse"));
        utilisateur.setCin(rs.getString("cin"));
        utilisateur.setTelephone(rs.getString("telephone"));

        var dn = rs.getDate("dateNaissance");
        if (dn != null) utilisateur.setDateNaissance(dn.toLocalDate());

        var lastLogin = rs.getTimestamp("lastLoginDate");
        if (lastLogin != null)
            utilisateur.setLastLoginDate(lastLogin.toLocalDateTime());

        utilisateur.setMotDePasse(rs.getString("motDePasse"));

        // relations via services

        return utilisateur;

    }
    // ============================================================
//  CABINET MEDICALE
// ============================================================
    public static CabinetMedicale mapCabinetMedical(ResultSet rs) throws SQLException {

        CabinetMedicale c = mapBaseEntity(rs, new CabinetMedicale());

        c.setNom(rs.getString("nom"));
        c.setEmail(rs.getString("email"));
        c.setLogo(rs.getString("logo"));
        c.setCategorie(rs.getString("categorie"));
        c.setTel1(rs.getString("tel1"));
        c.setTel2(rs.getString("tel2"));
        c.setSiteWeb(rs.getString("siteWeb"));
        c.setInstagram(rs.getString("instagram"));
        c.setFacebook(rs.getString("facebook"));
        c.setDescription(rs.getString("description"));

        return c;
    }
    // ============================================================
    // Statistiques
    // ============================================================
    public static Statistiques mapStatistiques(ResultSet rs) throws SQLException {
        Statistiques s = mapBaseEntity(rs, new Statistiques());

        s.setNom(rs.getString("nom"));

        String cat = rs.getString("categorie");
        if (cat != null) s.setCategorie(CategorieStatistique.valueOf(cat));

        double chiffre = rs.getDouble("chiffre");
        if (!rs.wasNull()) s.setChiffre(chiffre);

        java.sql.Date d = rs.getDate("dateCalcul");
        if (d != null) s.setDateCalcul(d.toLocalDate());

        // Chargement minimal de CabinetMedicale : juste l'ID
        long cabinetId = rs.getLong("cabinet_id");
        if (!rs.wasNull()) {
            CabinetMedicale c = new CabinetMedicale();
            c.setId(cabinetId);
            s.setCabinetMedicale(c);
        }

        return s;
    }
    // ============================================================
    // ACTE MEDICAL
    // ============================================================
        public static ActeMedical mapActeMedical(ResultSet rs) throws SQLException {
            ActeMedical acte = mapBaseEntity(rs, new ActeMedical());

            acte.setLibelle(rs.getString("libelle"));
            acte.setCategorie(rs.getString("categorie"));
            acte.setPrixDeBase(rs.getFloat("prixDeBase"));

            // La liste d'interventions sera chargée via le service
            acte.setInterventionMedecin(new ArrayList<>());

            return acte;
        }
    // ============================================================
// CONSULTATION
// ============================================================
    public static Consultation mapConsultation(ResultSet rs) throws SQLException {
        Consultation c = mapBaseEntity(rs, new Consultation());

        Timestamp dt = rs.getTimestamp("date");
        if (dt != null) c.setDate(dt.toLocalDateTime());

        String status = rs.getString("status");
        if (status != null) c.setStatus(StatusConsultation.valueOf(status));

        c.setNotes(rs.getString("notes"));
        c.setObservationsMedecin(rs.getString("observationsMedecin"));

        // Les relations complexes (ordonnances, certificats, factures, rendez-vous, DossierMedical, IMS)
        // seront chargées via le service ou repository spécifique
        c.setOrdonnances(new ArrayList<>());
        c.setCertificats(null);
        c.setIms(new ArrayList<>());
        c.setFactures(new ArrayList<>());
        c.setRendezVouses(new ArrayList<>());
        c.setDossierMedical(null);

        return c;
    }
    // ============================================================
// INTERVENTION MEDECIN
// ============================================================
    public static InterventionMedecin mapInterventionMedecin(ResultSet rs) throws SQLException {
        InterventionMedecin im = mapBaseEntity(rs, new InterventionMedecin());

        im.setPrixDePatient(rs.getDouble("prixDePatient"));
        im.setNumDent(rs.getInt("numDent"));

        // Les relations Consultation et ActeMedical seront chargées via le service ou repository
        im.setConsultation(null);
        im.setActeMedical(null);

        return im;
    }
    // ============================================================
// CHARGES
// ============================================================
    public static Charges mapCharges(ResultSet rs) throws SQLException {
        Charges c = mapBaseEntity(rs, new Charges());

        c.setTitre(rs.getString("titre"));
        c.setDescription(rs.getString("description"));
        c.setMontant(rs.getDouble("montant"));

        Timestamp dt = rs.getTimestamp("date");
        if (dt != null) c.setDate(dt.toLocalDateTime());

        // Relation CabinetMedicale à charger via service
        c.setCabinetMedicale(null);

        return c;
    }

    // ============================================================
// REVENUS
// ============================================================
    public static Revenus mapRevenus(ResultSet rs) throws SQLException {
        Revenus r = mapBaseEntity(rs, new Revenus());

        r.setTitre(rs.getString("titre"));
        r.setDescription(rs.getString("description"));
        r.setMontant(rs.getDouble("montant"));

        Timestamp dt = rs.getTimestamp("date");
        if (dt != null) r.setDate(dt.toLocalDateTime());

        r.setCabinetMedicale(null); // Relation à charger via service

        return r;
    }

    // ============================================================
// FACTURE
// ============================================================
    public static Facture mapFacture(ResultSet rs) throws SQLException {
        Facture f = mapBaseEntity(rs, new Facture());

        f.setTotalFact(rs.getFloat("totalFact"));
        f.setTotalPaye(rs.getFloat("totalPaye"));
        f.setReste(rs.getFloat("reste"));

        Date d = rs.getDate("date");
        if (d != null) f.setDate(d.toLocalDate());

        String statut = rs.getString("statut");
        if (statut != null) f.setStatut(StatutFacture.valueOf(statut));

        // Relations Consultation et SuiviFinancier à charger via service
        f.setConsultation(null);
        f.setSf(null);

        return f;
    }

    // ============================================================
// SUIVI FINANCIER
// ============================================================
    public static SuiviFinancier mapSuiviFinancier(ResultSet rs) throws SQLException {
        SuiviFinancier sf = mapBaseEntity(rs, new SuiviFinancier());

        sf.setTotalDesActes(rs.getFloat("totalDesActes"));
        sf.setTotalPaye(rs.getFloat("totalPaye"));
        sf.setCredit(rs.getFloat("credit"));
        sf.setDebit(rs.getFloat("debit"));

        String enPromo = rs.getString("enPromo");
        if (enPromo != null) sf.setEnPromo(PromoStatus.valueOf(enPromo));

        String status = rs.getString("status");
        if (status != null) sf.setStatus(Status.valueOf(status));

        // Relations listeFactures et dossierMedical à charger via service
        sf.setListeFactures(new ArrayList<>());
        sf.setDossierMedical(null);

        return sf;
    }
        // ============================================================
    //  ADMIN
    // ============================================================
    public static Admin mapAdmin(ResultSet rs) throws SQLException {
        Admin admin = mapUtilisateur(rs, new Admin());
        // Si tu veux ajouter des champs spécifiques à Admin plus tard, tu peux les mapper ici
        return admin;
    }
        // ============================================================
    //  MEDECIN
    // ============================================================
    public static Medecin mapMedecin(ResultSet rs) throws SQLException {
        Medecin medecin = (Medecin) mapUtilisateur(rs, new Medecin());

        // Champs spécifiques à Medecin
        medecin.setSpecialite(rs.getString("specialite"));

        // Si tu veux mapper agendaDocteur ou dossiersMed plus tard, il faudra charger via service ou JOIN

        return medecin;
    }
    // ============================================================
//  SECRETAIRE
// ============================================================
    public static Secretaire mapSecretaire(ResultSet rs) throws SQLException {
        Secretaire s = (Secretaire) mapUtilisateur(rs, new Secretaire());

        s.setNumCNS(rs.getString("numCNS"));
        s.setCommission(rs.getDouble("commission"));

        return s;
    }
    // ============================================================
//  STAFF
// ============================================================
    public static Staff mapStaff(ResultSet rs) throws SQLException {
        Staff s = (Staff) mapUtilisateur(rs, new Staff());

        s.setSalaire(rs.getDouble("salaire"));
        s.setPrime(rs.getDouble("prime"));

        var dateRec = rs.getDate("dateRecrutement");
        if (dateRec != null) s.setDateRecrutement(dateRec.toLocalDate());

        s.setSoldeConge(rs.getInt("soldeConge"));

        // Relation CabinetMedicale (juste l'id, le reste peut être chargé via service)
        long cabinetId = rs.getLong("cabinetMedicale_id");
        if (!rs.wasNull()) {
            s.setCabinetMedicale(new CabinetMedicale());
            s.getCabinetMedicale().setId(cabinetId);
        }

        return s;
    }
    public static AgendaMensuel mapAgendaMensuel(ResultSet rs) throws SQLException {
        AgendaMensuel a = new AgendaMensuel();

        a.setId(rs.getLong("id"));
        a.setMois(rs.getString("mois") != null ? Mois.valueOf(rs.getString("mois")) : null);

        String jours = rs.getString("jours_non_disponible");
        if (jours != null && !jours.isEmpty()) {
            a.setJoursNonDisponible(List.of(jours.split(",")));
        }

        long medId = rs.getLong("medecin_id");
        if (!rs.wasNull()) {
            Medecin m = new Medecin();
            m.setId(medId);
            a.setMedecin(m);
        }

        return a;
    }
    public static RendezVous mapRendezVous(ResultSet rs) throws SQLException {
        RendezVous r = new RendezVous();

        r.setId(rs.getLong("id"));
        r.setDate(rs.getTimestamp("date_rdv") != null ? rs.getTimestamp("date_rdv").toLocalDateTime() : null);
        r.setTime(rs.getTime("heure_rdv") != null ? rs.getTime("heure_rdv").toLocalTime() : null);
        r.setMotif(rs.getString("motif"));

        String st = rs.getString("status");
        r.setStatus(st != null ? Status.valueOf(st) : null);

        r.setNoteMedecin(rs.getString("note_medecin"));

        // dossier médical
        long dmid = rs.getLong("dossier_med_id");
        if (!rs.wasNull()) {
            var dm = new DossierMedical();
            dm.setId(dmid);
            r.setDossierMed(dm);
        }

        // consultation
        long cid = rs.getLong("consultation_id");
        if (!rs.wasNull()) {
            var c = new Consultation();
            c.setId(cid);
            r.setConsultation(c);
        }

        return r;
    }
    public static Medicament mapMedicament(ResultSet rs) throws SQLException {
        Medicament m = new Medicament();

        m.setId(rs.getLong("id"));
        m.setNom(rs.getString("nom"));
        m.setLabo(rs.getString("labo"));
        m.setType(rs.getString("type"));

        String f = rs.getString("forme");
        m.setForme(f != null ? Forme.valueOf(f) : null);

        m.setRemboursable(rs.getBoolean("remboursable"));
        m.setPrixUnitaire(rs.getDouble("prix_unitaire"));
        m.setDescription(rs.getString("description"));

        // prescriptions NON CHARGEES ici (Lazy)
        m.setPrescriptions(null);

        return m;
    }
    public static Ordonnance mapOrdonnance(ResultSet rs) throws SQLException {
        Ordonnance o = new Ordonnance();

        o.setId(rs.getLong("id"));
        o.setDateOrdonnance(rs.getDate("date_ordonnance") != null ? rs.getDate("date_ordonnance").toLocalDate() : null);

        // Relations : consultation et dossierMedical
        long consultationId = rs.getLong("consultation_id");
        if (!rs.wasNull()) {
            Consultation c = new Consultation();
            c.setId(consultationId);
            o.setConsultation(c);
        }

        long dossierId = rs.getLong("dossier_medical_id");
        if (!rs.wasNull()) {
            DossierMedical d = new DossierMedical();
            d.setId(dossierId);
            o.setDossierMedical(d);
        }

        // prescriptions NON CHARGEES ici (lazy)
        o.setPrescriptions(null);

        return o;
    }
    public static Prescription mapPrescription(ResultSet rs) throws SQLException {
        Prescription p = new Prescription();

        p.setId(rs.getLong("id"));
        p.setQte(rs.getInt("qte"));
        p.setFrequence(rs.getString("frequence"));
        p.setDuree(rs.getInt("duree"));

        // Relations : ordonnance et medicament
        long ordonnanceId = rs.getLong("ordonnance_id");
        if (!rs.wasNull()) {
            Ordonnance o = new Ordonnance();
            o.setId(ordonnanceId);
            p.setOrdonnance(o);
        }

        long medicamentId = rs.getLong("medicament_id");
        if (!rs.wasNull()) {
            Medicament m = new Medicament();
            m.setId(medicamentId);
            p.setMedicament(m);
        }

        return p;
    }

}
