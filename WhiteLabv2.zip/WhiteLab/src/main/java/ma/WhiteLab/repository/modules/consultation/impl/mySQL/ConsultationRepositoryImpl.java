package ma.WhiteLab.repository.modules.consultation.impl.mySQL;

import ma.WhiteLab.conf.SessionFactory;
import ma.WhiteLab.entities.consultation.Consultation;
import ma.WhiteLab.repository.common.RowMappers;
import ma.WhiteLab.repository.modules.consultation.api.ConsultationRepository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ConsultationRepositoryImpl implements ConsultationRepository {

    @Override
    public List<Consultation> findAll() {
        String sql = "SELECT * FROM consultation ORDER BY date DESC";
        List<Consultation> out = new ArrayList<>();
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) out.add(RowMappers.mapConsultation(rs));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return out;
    }

    @Override
    public Consultation findById(Long id) {
        String sql = "SELECT * FROM consultation WHERE id = ?";
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return RowMappers.mapConsultation(rs);
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void create(Consultation c) {
        String sql = """
                INSERT INTO consultation(date, status, notes, observationsMedecin, dateCreation, creePar)
                VALUES (?, ?, ?, ?, ?, ?)
                """;

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setTimestamp(1, c.getDate() != null ? Timestamp.valueOf(c.getDate()) : null);
            ps.setString(2, c.getStatus() != null ? c.getStatus().name() : null);
            ps.setString(3, c.getNotes());
            ps.setString(4, c.getObservationsMedecin());
            ps.setTimestamp(5, Timestamp.valueOf(c.getDateCreation() != null ? c.getDateCreation() : java.time.LocalDateTime.now()));
            ps.setString(6, c.getCreePar());

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) c.setId(keys.getLong(1));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update(Consultation c) {
        String sql = """
                UPDATE consultation
                SET date=?, status=?, notes=?, observationsMedecin=?, dateMiseAJour=?, modifierPar=?
                WHERE id=?
                """;

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setTimestamp(1, c.getDate() != null ? Timestamp.valueOf(c.getDate()) : null);
            ps.setString(2, c.getStatus() != null ? c.getStatus().name() : null);
            ps.setString(3, c.getNotes());
            ps.setString(4, c.getObservationsMedecin());
            ps.setTimestamp(5, Timestamp.valueOf(java.time.LocalDateTime.now()));
            ps.setString(6, c.getModifierPar());
            ps.setLong(7, c.getId());

            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(Consultation c) {
        if (c != null) deleteById(c.getId());
    }

    @Override
    public void deleteById(Long id) {
        String sql = "DELETE FROM consultation WHERE id = ?";

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Consultation> findByStatus(String status) {
        String sql = "SELECT * FROM consultation WHERE status = ? ORDER BY date DESC";
        List<Consultation> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(RowMappers.mapConsultation(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return out;
    }

    @Override
    public List<Consultation> findByDossierMedicalId(Long dossierId) {
        String sql = "SELECT * FROM consultation WHERE dossier_id = ? ORDER BY date DESC";
        List<Consultation> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, dossierId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(RowMappers.mapConsultation(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return out;
    }
}
