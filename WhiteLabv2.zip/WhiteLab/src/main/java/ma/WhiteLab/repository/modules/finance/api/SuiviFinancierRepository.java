package ma.WhiteLab.repository.modules.finance.api;

import ma.WhiteLab.entities.finance.SuiviFinancier;
import ma.WhiteLab.repository.common.CrudRepository;

import java.util.List;

public interface SuiviFinancierRepository extends CrudRepository<SuiviFinancier, Long> {

    // Récupérer le suivi financier d'un dossier médical spécifique
    List<SuiviFinancier> findByDossierId(Long dossierId);

    // Récupérer tous les suivis financiers actifs
    List<SuiviFinancier> findByStatus(String status);

    // Récupérer tous les suivis financiers en promo
    List<SuiviFinancier> findByPromo(String promoStatus);
}
