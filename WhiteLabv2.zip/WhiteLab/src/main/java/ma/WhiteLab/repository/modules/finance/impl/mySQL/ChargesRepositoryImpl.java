package ma.WhiteLab.repository.modules.finance.impl.mySQL;

import ma.WhiteLab.conf.SessionFactory;
import ma.WhiteLab.entities.finance.Charges;
import ma.WhiteLab.repository.common.CrudRepository;
import ma.WhiteLab.repository.common.RowMappers;
import ma.WhiteLab.repository.modules.finance.api.ChargesRepository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ChargesRepositoryImpl implements ChargesRepository {

    @Override
    public List<Charges> findAll() {
        String sql = "SELECT * FROM charges ORDER BY date DESC";
        List<Charges> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) out.add(RowMappers.mapCharges(rs));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return out;
    }

    @Override
    public Charges findById(Long id) {
        String sql = "SELECT * FROM charges WHERE id = ?";
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return RowMappers.mapCharges(rs);
                return null;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void create(Charges c) {
        String sql = """
                INSERT INTO charges(titre, description, montant, date, dateCreation, creePar)
                VALUES (?, ?, ?, ?, ?, ?)
                """;

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, c.getTitre());
            ps.setString(2, c.getDescription());
            ps.setDouble(3, c.getMontant());
            ps.setTimestamp(4, c.getDate() != null ? Timestamp.valueOf(c.getDate()) : null);
            ps.setTimestamp(5, Timestamp.valueOf(c.getDateCreation() != null ? c.getDateCreation() : java.time.LocalDateTime.now()));
            ps.setString(6, c.getCreePar());

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) c.setId(keys.getLong(1));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update(Charges c) {
        String sql = """
                UPDATE charges
                SET titre=?, description=?, montant=?, date=?, dateMiseAJour=?, modifierPar=?
                WHERE id=?
                """;

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, c.getTitre());
            ps.setString(2, c.getDescription());
            ps.setDouble(3, c.getMontant());
            ps.setTimestamp(4, c.getDate() != null ? Timestamp.valueOf(c.getDate()) : null);
            ps.setTimestamp(5, Timestamp.valueOf(java.time.LocalDateTime.now()));
            ps.setString(6, c.getModifierPar());
            ps.setLong(7, c.getId());

            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(Charges c) {
        if (c != null) deleteById(c.getId());
    }

    @Override
    public void deleteById(Long id) {
        String sql = "DELETE FROM charges WHERE id = ?";

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public List<Charges> findByCabinetId(Long cabinetId) {
        String sql = "SELECT * FROM charges WHERE cabinet_id = ? ORDER BY date DESC";
        List<Charges> out = new ArrayList<>();
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, cabinetId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(RowMappers.mapCharges(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return out;
    }

    @Override
    public List<Charges> findByDateBetween(java.time.LocalDateTime start, java.time.LocalDateTime end) {
        String sql = "SELECT * FROM charges WHERE date BETWEEN ? AND ? ORDER BY date DESC";
        List<Charges> out = new ArrayList<>();
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setTimestamp(1, Timestamp.valueOf(start));
            ps.setTimestamp(2, Timestamp.valueOf(end));

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(RowMappers.mapCharges(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return out;
    }


}
