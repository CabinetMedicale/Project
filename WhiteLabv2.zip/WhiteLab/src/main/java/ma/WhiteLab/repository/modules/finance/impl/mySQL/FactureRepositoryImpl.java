package ma.WhiteLab.repository.modules.finance.impl.mySQL;

import ma.WhiteLab.conf.SessionFactory;
import ma.WhiteLab.entities.finance.Facture;
import ma.WhiteLab.repository.common.CrudRepository;
import ma.WhiteLab.repository.common.RowMappers;
import ma.WhiteLab.repository.modules.finance.api.FactureRepository;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class FactureRepositoryImpl implements FactureRepository {

    @Override
    public List<Facture> findAll() {
        String sql = "SELECT * FROM facture ORDER BY date DESC";
        List<Facture> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) out.add(RowMappers.mapFacture(rs));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return out;
    }

    @Override
    public Facture findById(Long id) {
        String sql = "SELECT * FROM facture WHERE id = ?";
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return RowMappers.mapFacture(rs);
                return null;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void create(Facture f) {
        String sql = """
                INSERT INTO facture(totalFact, totalPaye, reste, date, statut, dateCreation, creePar)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """;

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setFloat(1, f.getTotalFact());
            ps.setFloat(2, f.getTotalPaye());
            ps.setFloat(3, f.getReste());
            ps.setDate(4, f.getDate() != null ? Date.valueOf(f.getDate()) : null);
            ps.setString(5, f.getStatut().name());
            ps.setTimestamp(6, Timestamp.valueOf(f.getDateCreation() != null ? f.getDateCreation() : java.time.LocalDateTime.now()));
            ps.setString(7, f.getCreePar());

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) f.setId(keys.getLong(1));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update(Facture f) {
        String sql = """
                UPDATE facture
                SET totalFact=?, totalPaye=?, reste=?, date=?, statut=?, dateMiseAJour=?, modifierPar=?
                WHERE id=?
                """;

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setFloat(1, f.getTotalFact());
            ps.setFloat(2, f.getTotalPaye());
            ps.setFloat(3, f.getReste());
            ps.setDate(4, f.getDate() != null ? Date.valueOf(f.getDate()) : null);
            ps.setString(5, f.getStatut().name());
            ps.setTimestamp(6, Timestamp.valueOf(java.time.LocalDateTime.now()));
            ps.setString(7, f.getModifierPar());
            ps.setLong(8, f.getId());

            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(Facture f) {
        if (f != null) deleteById(f.getId());
    }

    @Override
    public void deleteById(Long id) {
        String sql = "DELETE FROM facture WHERE id = ?";
        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public List<Facture> findByConsultationId(Long consultationId) {
        String sql = "SELECT * FROM facture WHERE consultation_id = ? ORDER BY date DESC";
        List<Facture> out = new ArrayList<>();
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, consultationId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(RowMappers.mapFacture(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return out;
    }

    public List<Facture> findByStatut(String statut) {
        String sql = "SELECT * FROM facture WHERE statut = ? ORDER BY date DESC";
        List<Facture> out = new ArrayList<>();
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, statut);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(RowMappers.mapFacture(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return out;
    }

    public List<Facture> findByDateBetween(LocalDate start, LocalDate end) {
        String sql = "SELECT * FROM facture WHERE date BETWEEN ? AND ? ORDER BY date DESC";
        List<Facture> out = new ArrayList<>();
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setDate(1, Date.valueOf(start));
            ps.setDate(2, Date.valueOf(end));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(RowMappers.mapFacture(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return out;
    }

}
