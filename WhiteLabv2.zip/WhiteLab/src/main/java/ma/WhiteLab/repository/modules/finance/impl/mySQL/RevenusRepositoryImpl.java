package ma.WhiteLab.repository.modules.finance.impl.mySQL;

import ma.WhiteLab.conf.SessionFactory;
import ma.WhiteLab.entities.finance.Revenus;
import ma.WhiteLab.repository.common.CrudRepository;
import ma.WhiteLab.repository.common.RowMappers;
import ma.WhiteLab.repository.modules.finance.api.RevenusRepository;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class RevenusRepositoryImpl implements RevenusRepository {

    @Override
    public List<Revenus> findAll() {
        String sql = "SELECT * FROM revenus ORDER BY date DESC";
        List<Revenus> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) out.add(RowMappers.mapRevenus(rs));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return out;
    }

    @Override
    public Revenus findById(Long id) {
        String sql = "SELECT * FROM revenus WHERE id = ?";
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return RowMappers.mapRevenus(rs);
                return null;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void create(Revenus r) {
        String sql = """
                INSERT INTO revenus(titre, description, montant, date, dateCreation, creePar)
                VALUES (?, ?, ?, ?, ?, ?)
                """;

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, r.getTitre());
            ps.setString(2, r.getDescription());
            ps.setDouble(3, r.getMontant());
            ps.setTimestamp(4, r.getDate() != null ? Timestamp.valueOf(r.getDate()) : null);
            ps.setTimestamp(5, Timestamp.valueOf(r.getDateCreation() != null ? r.getDateCreation() : java.time.LocalDateTime.now()));
            ps.setString(6, r.getCreePar());

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) r.setId(keys.getLong(1));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update(Revenus r) {
        String sql = """
                UPDATE revenus
                SET titre=?, description=?, montant=?, date=?, dateMiseAJour=?, modifierPar=?
                WHERE id=?
                """;

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, r.getTitre());
            ps.setString(2, r.getDescription());
            ps.setDouble(3, r.getMontant());
            ps.setTimestamp(4, r.getDate() != null ? Timestamp.valueOf(r.getDate()) : null);
            ps.setTimestamp(5, Timestamp.valueOf(java.time.LocalDateTime.now()));
            ps.setString(6, r.getModifierPar());
            ps.setLong(7, r.getId());

            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(Revenus r) {
        if (r != null) deleteById(r.getId());
    }

    @Override
    public void deleteById(Long id) {
        String sql = "DELETE FROM revenus WHERE id = ?";
        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public List<Revenus> findByCabinetId(Long cabinetId) {
        String sql = "SELECT * FROM revenus WHERE cabinet_id = ? ORDER BY date DESC";
        List<Revenus> out = new ArrayList<>();
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, cabinetId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(RowMappers.mapRevenus(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return out;
    }

    public List<Revenus> findByDateBetween(LocalDateTime start, LocalDateTime end) {
        String sql = "SELECT * FROM revenus WHERE date BETWEEN ? AND ? ORDER BY date DESC";
        List<Revenus> out = new ArrayList<>();
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setTimestamp(1, Timestamp.valueOf(start));
            ps.setTimestamp(2, Timestamp.valueOf(end));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(RowMappers.mapRevenus(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return out;
    }

    public List<Revenus> findByTitre(String titre) {
        String sql = "SELECT * FROM revenus WHERE titre = ? ORDER BY date DESC";
        List<Revenus> out = new ArrayList<>();
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, titre);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(RowMappers.mapRevenus(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return out;
    }

}
