package ma.WhiteLab.repository.modules.finance.impl.mySQL;

import ma.WhiteLab.conf.SessionFactory;
import ma.WhiteLab.entities.finance.SuiviFinancier;
import ma.WhiteLab.repository.common.RowMappers;
import ma.WhiteLab.repository.modules.finance.api.SuiviFinancierRepository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SuiviFinancierRepositoryImpl implements SuiviFinancierRepository {

    @Override
    public List<SuiviFinancier> findAll() {
        String sql = "SELECT * FROM suivi_financier ORDER BY dateCreation DESC";
        List<SuiviFinancier> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) out.add(RowMappers.mapSuiviFinancier(rs));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return out;
    }

    @Override
    public SuiviFinancier findById(Long id) {
        String sql = "SELECT * FROM suivi_financier WHERE id = ?";
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return RowMappers.mapSuiviFinancier(rs);
                return null;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void create(SuiviFinancier sf) {
        String sql = """
                INSERT INTO suivi_financier(totalDesActes, totalPaye, credit, debit, enPromo, status, dateCreation, creePar)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setFloat(1, sf.getTotalDesActes());
            ps.setFloat(2, sf.getTotalPaye());
            ps.setFloat(3, sf.getCredit());
            ps.setFloat(4, sf.getDebit());
            ps.setString(5, sf.getEnPromo() != null ? sf.getEnPromo().name() : null);
            ps.setString(6, sf.getStatus() != null ? sf.getStatus().name() : null);
            ps.setTimestamp(7, Timestamp.valueOf(sf.getDateCreation() != null ? sf.getDateCreation() : java.time.LocalDateTime.now()));
            ps.setString(8, sf.getCreePar());

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) sf.setId(keys.getLong(1));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update(SuiviFinancier sf) {
        String sql = """
                UPDATE suivi_financier
                SET totalDesActes=?, totalPaye=?, credit=?, debit=?, enPromo=?, status=?, dateMiseAJour=?, modifierPar=?
                WHERE id=?
                """;

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setFloat(1, sf.getTotalDesActes());
            ps.setFloat(2, sf.getTotalPaye());
            ps.setFloat(3, sf.getCredit());
            ps.setFloat(4, sf.getDebit());
            ps.setString(5, sf.getEnPromo() != null ? sf.getEnPromo().name() : null);
            ps.setString(6, sf.getStatus() != null ? sf.getStatus().name() : null);
            ps.setTimestamp(7, Timestamp.valueOf(java.time.LocalDateTime.now()));
            ps.setString(8, sf.getModifierPar());
            ps.setLong(9, sf.getId());

            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(SuiviFinancier sf) {
        if (sf != null) deleteById(sf.getId());
    }

    @Override
    public void deleteById(Long id) {
        String sql = "DELETE FROM suivi_financier WHERE id = ?";
        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Méthodes spécifiques
    @Override
    public List<SuiviFinancier> findByDossierId(Long dossierId) {
        String sql = "SELECT * FROM suivi_financier WHERE dossierMedical_id = ? ORDER BY dateCreation DESC";
        List<SuiviFinancier> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, dossierId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(RowMappers.mapSuiviFinancier(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return out;
    }

    @Override
    public List<SuiviFinancier> findByStatus(String status) {
        String sql = "SELECT * FROM suivi_financier WHERE status = ? ORDER BY dateCreation DESC";
        List<SuiviFinancier> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(RowMappers.mapSuiviFinancier(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return out;
    }

    @Override
    public List<SuiviFinancier> findByPromo(String promoStatus) {
        String sql = "SELECT * FROM suivi_financier WHERE enPromo = ? ORDER BY dateCreation DESC";
        List<SuiviFinancier> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, promoStatus);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(RowMappers.mapSuiviFinancier(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return out;
    }
}
