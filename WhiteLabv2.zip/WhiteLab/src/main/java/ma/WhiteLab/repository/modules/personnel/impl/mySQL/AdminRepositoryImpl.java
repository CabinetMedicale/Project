package ma.WhiteLab.repository.modules.personnel.impl.mySQL;

import ma.WhiteLab.conf.SessionFactory;
import ma.WhiteLab.entities.personnel.Admin;
import ma.WhiteLab.repository.modules.personnel.api.AdminRepository;
import ma.WhiteLab.repository.common.RowMappers;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AdminRepositoryImpl implements AdminRepository {

    @Override
    public List<Admin> findAll() {
        String sql = "SELECT * FROM utilisateur WHERE type = 'ADMIN'";
        List<Admin> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                out.add(RowMappers.mapAdmin(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return out;
    }

    @Override
    public Admin findById(Long id) {
        String sql = "SELECT * FROM utilisateur WHERE id = ? AND type = 'ADMIN'";
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return RowMappers.mapAdmin(rs);
                return null;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void create(Admin a) {
        String sql = """
                INSERT INTO utilisateur(nom, prenom, email, adresse, cin, telephone, dateNaissance, motDePasse, dateCreation, creePar, type)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ADMIN')
                """;

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, a.getNom());
            ps.setString(2, a.getPrenom());
            ps.setString(3, a.getEmail());
            ps.setString(4, a.getAdresse());
            ps.setString(5, a.getCin());
            ps.setString(6, a.getTelephone());
            ps.setDate(7, a.getDateNaissance() != null ? Date.valueOf(a.getDateNaissance()) : null);
            ps.setString(8, a.getMotDePasse());
            ps.setTimestamp(9, Timestamp.valueOf(a.getDateCreation() != null ? a.getDateCreation() : java.time.LocalDateTime.now()));
            ps.setString(10, a.getCreePar());

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) a.setId(keys.getLong(1));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update(Admin a) {
        String sql = """
                UPDATE utilisateur
                SET nom=?, prenom=?, email=?, adresse=?, cin=?, telephone=?, dateNaissance=?, motDePasse=?, dateMiseAJour=?, modifierPar=?
                WHERE id=? AND type = 'ADMIN'
                """;

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, a.getNom());
            ps.setString(2, a.getPrenom());
            ps.setString(3, a.getEmail());
            ps.setString(4, a.getAdresse());
            ps.setString(5, a.getCin());
            ps.setString(6, a.getTelephone());
            ps.setDate(7, a.getDateNaissance() != null ? Date.valueOf(a.getDateNaissance()) : null);
            ps.setString(8, a.getMotDePasse());
            ps.setTimestamp(9, Timestamp.valueOf(java.time.LocalDateTime.now()));
            ps.setString(10, a.getModifierPar());
            ps.setLong(11, a.getId());

            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(Admin a) {
        if (a != null) deleteById(a.getId());
    }

    @Override
    public void deleteById(Long id) {
        String sql = "DELETE FROM utilisateur WHERE id=? AND type='ADMIN'";
        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Optional<Admin> findByEmail(String email) {
        String sql = "SELECT * FROM utilisateur WHERE email = ? AND type='ADMIN'";
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(RowMappers.mapAdmin(rs));
                return Optional.empty();
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
