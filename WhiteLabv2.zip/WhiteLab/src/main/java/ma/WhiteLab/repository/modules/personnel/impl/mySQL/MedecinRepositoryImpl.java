package ma.WhiteLab.repository.modules.personnel.impl.mySQL;

import ma.WhiteLab.conf.SessionFactory;
import ma.WhiteLab.entities.personnel.Medecin;
import ma.WhiteLab.repository.modules.personnel.api.MedecinRepository;
import ma.WhiteLab.repository.common.RowMappers;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MedecinRepositoryImpl implements MedecinRepository {

    @Override
    public List<Medecin> findAll() {
        String sql = "SELECT * FROM utilisateur WHERE type = 'MEDECIN'";
        List<Medecin> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                out.add(RowMappers.mapMedecin(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return out;
    }

    @Override
    public Medecin findById(Long id) {
        String sql = "SELECT * FROM utilisateur WHERE id = ? AND type = 'MEDECIN'";
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return RowMappers.mapMedecin(rs);
                return null;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void create(Medecin m) {
        String sql = """
                INSERT INTO utilisateur(nom, prenom, email, adresse, cin, telephone, dateNaissance, motDePasse, dateCreation, creePar, type, specialite)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'MEDECIN', ?)
                """;

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, m.getNom());
            ps.setString(2, m.getPrenom());
            ps.setString(3, m.getEmail());
            ps.setString(4, m.getAdresse());
            ps.setString(5, m.getCin());
            ps.setString(6, m.getTelephone());
            ps.setDate(7, m.getDateNaissance() != null ? Date.valueOf(m.getDateNaissance()) : null);
            ps.setString(8, m.getMotDePasse());
            ps.setTimestamp(9, Timestamp.valueOf(m.getDateCreation() != null ? m.getDateCreation() : java.time.LocalDateTime.now()));
            ps.setString(10, m.getCreePar());
            ps.setString(11, m.getSpecialite());

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) m.setId(keys.getLong(1));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update(Medecin m) {
        String sql = """
                UPDATE utilisateur
                SET nom=?, prenom=?, email=?, adresse=?, cin=?, telephone=?, dateNaissance=?, motDePasse=?, dateMiseAJour=?, modifierPar=?, specialite=?
                WHERE id=? AND type = 'MEDECIN'
                """;

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, m.getNom());
            ps.setString(2, m.getPrenom());
            ps.setString(3, m.getEmail());
            ps.setString(4, m.getAdresse());
            ps.setString(5, m.getCin());
            ps.setString(6, m.getTelephone());
            ps.setDate(7, m.getDateNaissance() != null ? Date.valueOf(m.getDateNaissance()) : null);
            ps.setString(8, m.getMotDePasse());
            ps.setTimestamp(9, Timestamp.valueOf(java.time.LocalDateTime.now()));
            ps.setString(10, m.getModifierPar());
            ps.setString(11, m.getSpecialite());
            ps.setLong(12, m.getId());

            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(Medecin m) {
        if (m != null) deleteById(m.getId());
    }

    @Override
    public void deleteById(Long id) {
        String sql = "DELETE FROM utilisateur WHERE id=? AND type='MEDECIN'";
        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Optional<Medecin> findByEmail(String email) {
        String sql = "SELECT * FROM utilisateur WHERE email = ? AND type='MEDECIN'";
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(RowMappers.mapMedecin(rs));
                return Optional.empty();
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Medecin> findBySpecialite(String specialite) {
        String sql = "SELECT * FROM utilisateur WHERE specialite = ? AND type='MEDECIN'";
        List<Medecin> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, specialite);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(RowMappers.mapMedecin(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return out;
    }
}
