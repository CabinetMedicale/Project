package ma.WhiteLab.repository.modules.personnel.impl.mySQL;

import ma.WhiteLab.conf.SessionFactory;
import ma.WhiteLab.entities.personnel.Secretaire;
import ma.WhiteLab.repository.modules.personnel.api.SecretaireRepository;
import ma.WhiteLab.repository.common.RowMappers;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class SecretaireRepositoryImpl implements SecretaireRepository {

    @Override
    public List<Secretaire> findAll() {
        String sql = "SELECT * FROM utilisateur WHERE type = 'SECRETAIRE'";
        List<Secretaire> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) out.add(RowMappers.mapSecretaire(rs));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return out;
    }

    @Override
    public Secretaire findById(Long id) {
        String sql = "SELECT * FROM utilisateur WHERE id = ? AND type = 'SECRETAIRE'";
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return RowMappers.mapSecretaire(rs);
                return null;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void create(Secretaire s) {
        String sql = """
                INSERT INTO utilisateur(
                    nom, prenom, email, adresse, cin, telephone, dateNaissance, motDePasse, dateCreation, creePar, type, numCNS, commission
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'SECRETAIRE', ?, ?)
                """;

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, s.getNom());
            ps.setString(2, s.getPrenom());
            ps.setString(3, s.getEmail());
            ps.setString(4, s.getAdresse());
            ps.setString(5, s.getCin());
            ps.setString(6, s.getTelephone());
            ps.setDate(7, s.getDateNaissance() != null ? Date.valueOf(s.getDateNaissance()) : null);
            ps.setString(8, s.getMotDePasse());
            ps.setTimestamp(9, Timestamp.valueOf(s.getDateCreation() != null ? s.getDateCreation() : java.time.LocalDateTime.now()));
            ps.setString(10, s.getCreePar());
            ps.setString(11, s.getNumCNS());
            ps.setDouble(12, s.getCommission() != null ? s.getCommission() : 0.0);

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) s.setId(keys.getLong(1));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update(Secretaire s) {
        String sql = """
                UPDATE utilisateur
                SET nom=?, prenom=?, email=?, adresse=?, cin=?, telephone=?, dateNaissance=?, motDePasse=?, dateMiseAJour=?, modifierPar=?, numCNS=?, commission=?
                WHERE id=? AND type = 'SECRETAIRE'
                """;

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, s.getNom());
            ps.setString(2, s.getPrenom());
            ps.setString(3, s.getEmail());
            ps.setString(4, s.getAdresse());
            ps.setString(5, s.getCin());
            ps.setString(6, s.getTelephone());
            ps.setDate(7, s.getDateNaissance() != null ? Date.valueOf(s.getDateNaissance()) : null);
            ps.setString(8, s.getMotDePasse());
            ps.setTimestamp(9, Timestamp.valueOf(java.time.LocalDateTime.now()));
            ps.setString(10, s.getModifierPar());
            ps.setString(11, s.getNumCNS());
            ps.setDouble(12, s.getCommission() != null ? s.getCommission() : 0.0);
            ps.setLong(13, s.getId());

            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(Secretaire s) {
        if (s != null) deleteById(s.getId());
    }

    @Override
    public void deleteById(Long id) {
        String sql = "DELETE FROM utilisateur WHERE id=? AND type='SECRETAIRE'";
        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Optional<Secretaire> findByNumCNS(String numCNS) {
        String sql = "SELECT * FROM utilisateur WHERE numCNS = ? AND type='SECRETAIRE'";
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, numCNS);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(RowMappers.mapSecretaire(rs));
                return Optional.empty();
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
