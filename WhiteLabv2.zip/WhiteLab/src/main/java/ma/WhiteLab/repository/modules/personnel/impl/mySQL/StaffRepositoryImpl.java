package ma.WhiteLab.repository.modules.personnel.impl.mySQL;

import ma.WhiteLab.conf.SessionFactory;
import ma.WhiteLab.entities.personnel.Staff;
import ma.WhiteLab.repository.modules.personnel.api.StaffRepository;
import ma.WhiteLab.repository.common.RowMappers;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StaffRepositoryImpl implements StaffRepository {

    @Override
    public List<Staff> findAll() {
        String sql = "SELECT * FROM utilisateur WHERE type IN ('STAFF','MEDECIN','SECRETAIRE','ADMIN')";
        List<Staff> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) out.add(RowMappers.mapStaff(rs));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return out;
    }

    @Override
    public Staff findById(Long id) {
        String sql = "SELECT * FROM utilisateur WHERE id = ? AND type IN ('STAFF','MEDECIN','SECRETAIRE','ADMIN')";
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return RowMappers.mapStaff(rs);
                return null;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void create(Staff s) {
        String sql = """
                INSERT INTO utilisateur(
                    nom, prenom, email, adresse, cin, telephone, dateNaissance, motDePasse,
                    dateCreation, creePar, type, salaire, prime, dateRecrutement, soldeConge, cabinetMedicale_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'STAFF', ?, ?, ?, ?, ?)
                """;

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, s.getNom());
            ps.setString(2, s.getPrenom());
            ps.setString(3, s.getEmail());
            ps.setString(4, s.getAdresse());
            ps.setString(5, s.getCin());
            ps.setString(6, s.getTelephone());
            ps.setDate(7, s.getDateNaissance() != null ? Date.valueOf(s.getDateNaissance()) : null);
            ps.setString(8, s.getMotDePasse());
            ps.setTimestamp(9, Timestamp.valueOf(s.getDateCreation() != null ? s.getDateCreation() : java.time.LocalDateTime.now()));
            ps.setString(10, s.getCreePar());
            ps.setDouble(11, s.getSalaire() != null ? s.getSalaire() : 0.0);
            ps.setDouble(12, s.getPrime() != null ? s.getPrime() : 0.0);
            ps.setDate(13, s.getDateRecrutement() != null ? Date.valueOf(s.getDateRecrutement()) : null);
            ps.setInt(14, s.getSoldeConge());
            ps.setLong(15, s.getCabinetMedicale() != null ? s.getCabinetMedicale().getId() : Types.NULL);

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) s.setId(keys.getLong(1));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update(Staff s) {
        String sql = """
                UPDATE utilisateur
                SET nom=?, prenom=?, email=?, adresse=?, cin=?, telephone=?, dateNaissance=?, motDePasse=?,
                    dateMiseAJour=?, modifierPar=?, salaire=?, prime=?, dateRecrutement=?, soldeConge=?, cabinetMedicale_id=?
                WHERE id = ? AND type IN ('STAFF','MEDECIN','SECRETAIRE','ADMIN')
                """;

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, s.getNom());
            ps.setString(2, s.getPrenom());
            ps.setString(3, s.getEmail());
            ps.setString(4, s.getAdresse());
            ps.setString(5, s.getCin());
            ps.setString(6, s.getTelephone());
            ps.setDate(7, s.getDateNaissance() != null ? Date.valueOf(s.getDateNaissance()) : null);
            ps.setString(8, s.getMotDePasse());
            ps.setTimestamp(9, Timestamp.valueOf(java.time.LocalDateTime.now()));
            ps.setString(10, s.getModifierPar());
            ps.setDouble(11, s.getSalaire() != null ? s.getSalaire() : 0.0);
            ps.setDouble(12, s.getPrime() != null ? s.getPrime() : 0.0);
            ps.setDate(13, s.getDateRecrutement() != null ? Date.valueOf(s.getDateRecrutement()) : null);
            ps.setInt(14, s.getSoldeConge());
            ps.setLong(15, s.getCabinetMedicale() != null ? s.getCabinetMedicale().getId() : Types.NULL);
            ps.setLong(16, s.getId());

            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(Staff s) {
        if (s != null) deleteById(s.getId());
    }

    @Override
    public void deleteById(Long id) {
        String sql = "DELETE FROM utilisateur WHERE id=? AND type IN ('STAFF','MEDECIN','SECRETAIRE','ADMIN')";
        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Staff> findByCabinetId(Long cabinetId) {
        String sql = "SELECT * FROM utilisateur WHERE cabinetMedicale_id = ? AND type IN ('STAFF','MEDECIN','SECRETAIRE','ADMIN')";
        List<Staff> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, cabinetId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(RowMappers.mapStaff(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return out;
    }
}
