package ma.WhiteLab.repository.modules.planning.impl.mySQL;

import ma.WhiteLab.conf.SessionFactory;
import ma.WhiteLab.entities.planning.AgendaMensuel;
import ma.WhiteLab.repository.common.RowMappers;
import ma.WhiteLab.repository.modules.planning.api.AgendaMensuelRepository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AgendaMensuelRepositoryImpl implements AgendaMensuelRepository {

    @Override
    public List<AgendaMensuel> findAll() {
        String sql = "SELECT * FROM agenda_mensuel";
        List<AgendaMensuel> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                out.add(RowMappers.mapAgendaMensuel(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return out;
    }

    @Override
    public AgendaMensuel findById(Long id) {
        String sql = "SELECT * FROM agenda_mensuel WHERE id = ?";

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return RowMappers.mapAgendaMensuel(rs);
                return null;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void create(AgendaMensuel a) {
        String sql = "INSERT INTO agenda_mensuel (mois, jours_non_disponible, medecin_id) VALUES (?, ?, ?)";

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, a.getMois() != null ? a.getMois().name() : null);
            ps.setString(2, a.getJoursNonDisponible() != null ? String.join(",", a.getJoursNonDisponible()) : null);
            ps.setLong(3, a.getMedecin() != null ? a.getMedecin().getId() : Types.NULL);

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) a.setId(keys.getLong(1));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update(AgendaMensuel a) {
        String sql = "UPDATE agenda_mensuel SET mois = ?, jours_non_disponible = ?, medecin_id = ? WHERE id = ?";

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, a.getMois() != null ? a.getMois().name() : null);
            ps.setString(2, a.getJoursNonDisponible() != null ? String.join(",", a.getJoursNonDisponible()) : null);
            ps.setLong(3, a.getMedecin() != null ? a.getMedecin().getId() : Types.NULL);
            ps.setLong(4, a.getId());

            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(AgendaMensuel a) {
        if (a != null) deleteById(a.getId());
    }

    @Override
    public void deleteById(Long id) {
        String sql = "DELETE FROM agenda_mensuel WHERE id = ?";

        try (Connection conn = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<AgendaMensuel> findByMedecinId(Long medecinId) {
        String sql = "SELECT * FROM agenda_mensuel WHERE medecin_id = ?";
        List<AgendaMensuel> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, medecinId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(RowMappers.mapAgendaMensuel(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return out;
    }

    @Override
    public List<AgendaMensuel> findByMedecinIdAndMois(Long medecinId, String mois) {
        String sql = "SELECT * FROM agenda_mensuel WHERE medecin_id = ? AND mois = ?";
        List<AgendaMensuel> out = new ArrayList<>();

        try (Connection c = SessionFactory.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setLong(1, medecinId);
            ps.setString(2, mois);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(RowMappers.mapAgendaMensuel(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return out;
    }
}
