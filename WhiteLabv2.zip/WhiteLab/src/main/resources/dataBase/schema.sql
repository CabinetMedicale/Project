-- Base de données WhiteLabDB
CREATE DATABASE IF NOT EXISTS WhiteLabDB;
USE WhiteLabDB;

-- =========================
-- Table ActeMedical
-- =========================
CREATE TABLE Acte_Medical (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    dateCreation DATETIME,
    dateMiseAJour DATETIME,
    creePar VARCHAR(255),
    modifierPar VARCHAR(255),
    libelle VARCHAR(255) NOT NULL,
    categorie VARCHAR(100),
    prixDeBase FLOAT
);

-- =========================
-- Table Consultation
-- =========================
CREATE TABLE Consultation (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    dateCreation DATETIME,
    dateMiseAJour DATETIME,
    creePar VARCHAR(255),
    modifierPar VARCHAR(255),
    date DATETIME,
    status VARCHAR(50),
    notes TEXT,
    observationsMedecin TEXT
);

-- =========================
-- Table InterventionMedecin
-- =========================
CREATE TABLE InterventionMedecin (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    dateCreation DATETIME,
    dateMiseAJour DATETIME,
    creePar VARCHAR(255),
    modifierPar VARCHAR(255),
    prixDePatient DOUBLE,
    numDent INT,
    consultation_id BIGINT,
    acteMedical_id BIGINT,
    FOREIGN KEY (consultation_id) REFERENCES Consultation(id) ON DELETE CASCADE,
    FOREIGN KEY (acteMedical_id) REFERENCES Acte_Medical(id) ON DELETE CASCADE
);

-- =========================
-- Table CabinetMedicale
-- =========================
CREATE TABLE CabinetMedicale (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    dateCreation DATETIME,
    dateMiseAJour DATETIME,
    creePar VARCHAR(255),
    modifierPar VARCHAR(255),
    nom VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    logo VARCHAR(255),
    categorie VARCHAR(100),
    tel1 VARCHAR(50),
    tel2 VARCHAR(50),
    siteWeb VARCHAR(255),
    instagram VARCHAR(255),
    facebook VARCHAR(255),
    description TEXT
);

-- =========================
-- Table Statistiques
-- =========================
CREATE TABLE Statistiques (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    dateCreation DATETIME,
    dateMiseAJour DATETIME,
    creePar VARCHAR(255),
    modifierPar VARCHAR(255),
    nom VARCHAR(255) NOT NULL,
    categorie VARCHAR(50),
    chiffre DOUBLE,
    dateCalcul DATE,
    cabinet_id BIGINT,
    FOREIGN KEY (cabinet_id) REFERENCES CabinetMedicale(id) ON DELETE CASCADE
);

-- =========================
-- Table Utilisateur
-- =========================
CREATE TABLE Utilisateur (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    dateCreation DATETIME,
    dateMiseAJour DATETIME,
    creePar VARCHAR(255),
    modifierPar VARCHAR(255),
    nom VARCHAR(255),
    prenom VARCHAR(255),
    email VARCHAR(255),
    adresse VARCHAR(255),
    cin VARCHAR(50),
    telephone VARCHAR(50),
    dateNaissance DATE,
    sexe VARCHAR(10),
    lastLoginDate DATETIME,
    motDePasse VARCHAR(255),
    salaire DOUBLE,
    prime DOUBLE,
    dateRecrutement DATE,
    soldeConge INT,
    cabinetMedicale_id BIGINT,
    specialite VARCHAR(255),
    numCNS VARCHAR(50),
    commission DOUBLE,
    type VARCHAR(50) NOT NULL,
    FOREIGN KEY (cabinetMedicale_id) REFERENCES CabinetMedicale(id) ON DELETE SET NULL
);

-- =========================
-- Table Patient
-- =========================
CREATE TABLE Patient (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    dateCreation DATETIME,
    dateMiseAJour DATETIME,
    creePar VARCHAR(255),
    modifierPar VARCHAR(255),
    nom VARCHAR(255) NOT NULL,
    prenom VARCHAR(255),
    sexe VARCHAR(10),
    email VARCHAR(255),
    dateNaissance DATE,
    adresse VARCHAR(255),
    telephone VARCHAR(50),
    assurance VARCHAR(50)
);

-- =========================
-- Table DossierMedical
-- =========================
CREATE TABLE DossierMedical (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    dateCreation DATETIME,
    dateMiseAJour DATETIME,
    creePar VARCHAR(255),
    modifierPar VARCHAR(255),
    historique TEXT,
    pat_id BIGINT,
    medcine_id BIGINT,
    CONSTRAINT fk_dossier_patient
        FOREIGN KEY (pat_id) REFERENCES Patient(id) ON DELETE SET NULL,
    CONSTRAINT fk_dossier_medecin
        FOREIGN KEY (medcine_id) REFERENCES Utilisateur(id) ON DELETE SET NULL
);

-- =========================
-- Table Antecedent
-- =========================
CREATE TABLE Antecedent (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(255) NOT NULL,
    description TEXT,
    categorie VARCHAR(50),
    niveauRisque VARCHAR(50),
    dateCreation DATETIME,
    dateMiseAJour DATETIME,
    creePar VARCHAR(255),
    modifierPar VARCHAR(255)
);

-- =========================
-- Table de liaison Patient <-> Antecedent
-- =========================
CREATE TABLE Patient_Antecedent (
    patient_id BIGINT NOT NULL,
    antecedent_id BIGINT NOT NULL,
    PRIMARY KEY (patient_id, antecedent_id),
    CONSTRAINT fk_pa_patient FOREIGN KEY (patient_id) REFERENCES Patient(id) ON DELETE CASCADE,
    CONSTRAINT fk_pa_antecedent FOREIGN KEY (antecedent_id) REFERENCES Antecedent(id) ON DELETE CASCADE
);

-- =========================
-- Table Certificat
-- =========================
CREATE TABLE Certificat (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    dateCreation DATETIME,
    dateMiseAJour DATETIME,
    creePar VARCHAR(255),
    modifierPar VARCHAR(255),
    dateDebut DATE,
    dateFin DATE,
    dureeRepos INT,
    contenu TEXT,
    consultation_id BIGINT,
    dossier_med_id BIGINT,
    FOREIGN KEY (consultation_id) REFERENCES Consultation(id) ON DELETE CASCADE,
    FOREIGN KEY (dossier_med_id) REFERENCES DossierMedical(id) ON DELETE CASCADE
);

-- =========================
-- Table AgendaMensuel
-- =========================
CREATE TABLE AgendaMensuel (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    dateCreation DATETIME,
    dateMiseAJour DATETIME,
    creePar VARCHAR(255),
    modifierPar VARCHAR(255),
    mois VARCHAR(20),
    medecin_id BIGINT,
    FOREIGN KEY (medecin_id) REFERENCES Utilisateur(id) ON DELETE CASCADE
);

-- =========================
-- Table RendezVous
-- =========================
CREATE TABLE RendezVous (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    dateCreation DATETIME,
    dateMiseAJour DATETIME,
    creePar VARCHAR(255),
    modifierPar VARCHAR(255),
    dateRDV DATETIME,
    heure_rdv TIME,
    motif VARCHAR(255),
    status VARCHAR(50),
    note_medecin TEXT,
    dossier_med_id BIGINT,
    consultation_id BIGINT,
    FOREIGN KEY (dossier_med_id) REFERENCES DossierMedical(id) ON DELETE CASCADE,
    FOREIGN KEY (consultation_id) REFERENCES Consultation(id) ON DELETE CASCADE
);

-- =========================
-- Table Medicament
-- =========================
CREATE TABLE Medicament (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    dateCreation DATETIME,
    dateMiseAJour DATETIME,
    creePar VARCHAR(255),
    modifierPar VARCHAR(255),
    nom VARCHAR(255),
    labo VARCHAR(255),
    type VARCHAR(50),
    forme VARCHAR(50),
    remboursable BOOLEAN,
    prix_unitaire DOUBLE,
    description TEXT
);

-- =========================
-- Table Ordonnance
-- =========================
CREATE TABLE Ordonnance (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    dateCreation DATETIME,
    dateMiseAJour DATETIME,
    creePar VARCHAR(255),
    modifierPar VARCHAR(255),
    date_ordonnance DATE,
    consultation_id BIGINT,
    dossier_med_id BIGINT,
    FOREIGN KEY (consultation_id) REFERENCES Consultation(id) ON DELETE CASCADE,
    FOREIGN KEY (dossier_med_id) REFERENCES DossierMedical(id) ON DELETE CASCADE
);

-- =========================
-- Table Prescription
-- =========================
CREATE TABLE Prescription (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    dateCreation DATETIME,
    dateMiseAJour DATETIME,
    creePar VARCHAR(255),
    modifierPar VARCHAR(255),
    qte INT,
    frequence VARCHAR(50),
    duree INT,
    ordonnance_id BIGINT,
    medicament_id BIGINT,
    FOREIGN KEY (ordonnance_id) REFERENCES Ordonnance(id) ON DELETE CASCADE,
    FOREIGN KEY (medicament_id) REFERENCES Medicament(id) ON DELETE CASCADE
);

-- =========================
-- Table Role
-- =========================
CREATE TABLE Role (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    libelle VARCHAR(50) NOT NULL,
    privileges TEXT,
    dateCreation DATETIME DEFAULT CURRENT_TIMESTAMP,
    dateMiseAJour DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    creePar VARCHAR(255),
    modifierPar VARCHAR(255)
);

-- =========================
-- Table Notification
-- =========================
CREATE TABLE Notification (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    titre VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    date DATE,
    time TIME,
    type VARCHAR(50) NOT NULL,
    priorite VARCHAR(50) NOT NULL,
    dateCreation DATETIME DEFAULT CURRENT_TIMESTAMP,
    dateMiseAJour DATETIME,
    creePar VARCHAR(100),
    modifierPar VARCHAR(100)
);

-- =========================
-- Table de liaison Utilisateur <-> Role
-- =========================
CREATE TABLE Utilisateur_Role (
    utilisateur_id BIGINT,
    role_id BIGINT,
    PRIMARY KEY(utilisateur_id, role_id),
    FOREIGN KEY (utilisateur_id) REFERENCES Utilisateur(id) ON DELETE CASCADE,
    FOREIGN KEY (role_id) REFERENCES Role(id) ON DELETE CASCADE
);

-- =========================
-- Table de liaison Utilisateur <-> Notification
-- =========================
CREATE TABLE Utilisateur_Notification (
    utilisateur_id BIGINT,
    notification_id BIGINT,
    PRIMARY KEY(utilisateur_id, notification_id),
    FOREIGN KEY (utilisateur_id) REFERENCES Utilisateur(id) ON DELETE CASCADE,
    FOREIGN KEY (notification_id) REFERENCES Notification(id) ON DELETE CASCADE
);
